<template>
  <div id="app">
<product-info title="Сир"
 :price="100"
 :tax="5"
 :total="105"
/>
  </div>
</template>

<script>
import ProductInfo from './components/ProductInfo'

export default {
  name: 'App',
  components: {
    ProductInfo
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
