<template>
    <div>
<div>
    <div>
    <label >
        First
        <input type="number" v-model="firstNum">
        <!-- <input type="number" :value="firstNum"> -->
    </label>
    </div>
    <div>
    <label >
        second
        <input type="number" v-model="secondNum">
    </label>
    </div>
    
    <button @click="getSum">
        Get summ
    </button>
    <button @click="getRandNums">
        Get random numbers
    </button>

    <div >
        Result: <span>{{result}}</span>        
    </div>
    <div>
       Computed: {{summ}}
    </div>
</div>
    </div>
</template>

<script>
    export default {
        name:"Summator",

        data() {
            return {
                firstNum: '12',
                secondNum: '22',
                result: null,
            }
        },

        computed: {
            summ() {
                return parseFloat(this.firstNum)+parseFloat(this.secondNum)
            }
        },

        methods: {
            getSum() {
                this.result=parseFloat(this.firstNum)+parseFloat(this.secondNum)
            },
            getRandNums(){
                this.firstNum=Math.floor(Math.random()*100)
                this.secondNum=Math.floor(Math.random()*100)
            }
        },
    }
</script>

<style lang="scss" scoped>

</style>