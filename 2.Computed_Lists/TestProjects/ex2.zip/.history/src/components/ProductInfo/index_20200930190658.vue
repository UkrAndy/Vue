<template>
<table>
    <tr>
        <td>Назва</td>
        <td>{{title}}</td>
    </tr>
    <tr>
        <td>Ціна</td>
        <td>{{price}}</td>
    </tr>
    <tr>
        <td>ПДВ</td>
        <td>{{tax}}</td>
    </tr>
    <tr>
        <td>Загалом</td>
        <!-- <td>{{total}}</td> -->
        <td>{{getTotal()}}</td>
    </tr>
</table>
</template>

<script>
    export default {
        name:'ProductInfo',

//Відні дані (які потрібні для роботи компонента)
        props: {
            title: {
                type: String,
                required:true
            },
            price:{
                type:Number,
                default:0
            },
            tax:{
                type:Number,
                default:0
            }

        },

//Величини, що обчислюються на основі інших даних
        computed: {
            total() {
                return this.price+this.price*this.tax/100
            }
        },
//Усі функції, що використовуються у компоненті
        methods: {
            getTotal() {
                return this.price+this.price*this.tax/100
            }
        },
    }
</script>

<style lang="css" scoped>
table{
    color: red;
}
</style>