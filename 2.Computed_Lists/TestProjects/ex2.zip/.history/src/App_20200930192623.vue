<template>
  <div id="app">
    <predictioner :items-list=""/>
<hr>
<product-info 
title="Сир"
 :price="100"
 :tax="5"
 
/>

  </div>
</template>

<script>
import ProductInfo from './components/ProductInfo'
import Predictioner from './components/Predictioner'

export default {
  name: 'App',
  components: {
    ProductInfo,
    Predictioner
  },

  data() {
    return {
      wishes: ['money', 'love','peace','friend','go home']
    }
  },
}
</script>

<style scoped>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
 
  color: #2c3e50;
  margin-top: 60px;
}
</style>
