<template>
    <div>
        Hello
    </div>
</template>

<script>
    export default {
        name:"MyBaner"
    }
</script>

<style lang="scss" scoped>

</style>