<template>
    <div>
<div>
    <label >
        First
        <input type="number" v-model="firstNum">
    </label>
    <label >
        second
        <input type="number" v-model="secondNum">
    </label>
    <button @click="getSum">
        Get summ
    </button>
    <label >
        Result: <span>{{result}}</span>        
    </label>
</div>
    </div>
</template>

<script>
    export default {
        name:"Summator",

        data() {
            return {
                firstNum: '12',
                secondNum: '22',
                result: null,
            }
        },

        methods: {
            getSum() {
                this.result=parseFloat(this.firstNum)+parseFloat(this.secondNum)
            }
        },
    }
</script>

<style lang="scss" scoped>

</style>