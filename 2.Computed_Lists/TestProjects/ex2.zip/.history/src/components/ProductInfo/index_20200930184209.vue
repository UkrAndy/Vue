<template>
<table>
    <tr>
        <td>Назва</td>
        <td>{{title}}</td>
    </tr>
    <tr>
        <td>Ціна</td>
        <td>{{price}}</td>
    </tr>
    <tr>
        <td>ПДВ</td>
        <td>{{tax}}</td>
    </tr>
    <tr>
        <td>Загалом</td>
        <td>{{total}}</td>
    </tr>
</table>
</template>

<script>
    export default {
        name:'ProductInfo',

        props: {
            title: {
                type: String,
                required:true
            },
            price:{
                type:Number,
                default:0
            },
            tax:{
                type:Number,
                default:0
            },
            total:{
                type:Number,
                default:0
            },

        },
    }
</script>

<style lang="css" scoped>
table{
    color: red;
}
</style>