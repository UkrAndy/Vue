<template>
  <div id="app">
    <my-baner  imgSrc="https://rastenievod.com/wp-content/uploads/2018/01/2-13-700x564.jpg"/>
  </div>
</template>

<script>
// import HelloWorld from './components/HelloWorld.vue'
import MyBaner from "./components/MyBaner";  //1. Імпортуємо

export default {
  name: 'App',
  components: {   
    MyBaner  //2. Реєстрація компонента
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
