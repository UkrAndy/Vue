<template>
    <div>
<div>
    <label >
        First
        <input type="number" :value="firstNum">
    </label>
    <label >
        second
        <input type="number" :value="seconNum">
    </label>
    <button>
        Get summ
    </button>
    <label >
        Result: <span>{{result}}</span>        
    </label>
</div>
    </div>
</template>

<script>
    export default {
        name:"Summator",

        data() {
            return {
                firstNum: null,
                seconNum: null,
                result: null,
            }
        },
    }
</script>

<style lang="scss" scoped>

</style>